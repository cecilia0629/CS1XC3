/**
  * @file     	course.c
  * @date    	Apr,12th,2022
  * @author  Shu Fang
  * @brief   	runs demonstration for student information of a course
  *
  */  

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 /**
 * creates the library of course represented as an array and tests the course
 * 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @param student pointer
 * @brief the function to print course information and student information
 * calloc used to store a new memory
 * realloc is used to reuse the memory before
 * use both of calloc and realloc are used for collecting student information in one array
 * 
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief the function is to	search the information of student with course information
 * for loop (print all student information who enroll the course )		
 * print with the format as above, Name, Code, Total students...)
 * 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief the function used to search the student who gets the highest average in the course
 * the condition is the course must has at least one student, if not return NUll
 * for loop (compare the value in the course array to find the maxmium value)		
 * @return the students with the highest average
 * 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
/**
 *  @brief the function allow us to count the number of student passes
 *  calloc - creates a new array for passsing student
 *  for stuents in the array of course, if the i student passes(greater or equal to 50), he/she will in the array of passsing
 * 	for all studnts passes, count the total number	
 *	last return the array of students who passes
 *
 */