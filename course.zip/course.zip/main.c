/**
  * @file     	course.c
  * @date    	Apr,12th,2022
  * @author  Shu Fang
  * @brief   	runs demonstration for time, course library method
  *
  */  
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * creates the library of time represented as an array and tests the time
 * creates the library of course represented as an array and tests the course
 * 
 */

int main()
{
  // Random seed initialization
  srand((unsigned) time(NULL));
 // create a new empty array to store information within the course Math101
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
 // enroll 20 students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  // use for loop to print passing students' informarion from the array of passing_student
  return 0;
}
/**
 * @brief use those functions to apply in other code
 * 
 */